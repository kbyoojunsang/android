package com.kbyoojunsang.restart2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. 처리할 버튼을 찾으세요.
        Button restart = findViewById(R.id.restart);

        // 2. 버튼을 클릭했을 때 처리할 것을 세팅
        restart.setOnClickListener(new View.OnClickListener() {
            // └ 클릭할때까지 기다리다가, 클릭하면 () 안의 공정을 실행한다는 의미
            //  new 치고 한칸띄고 ctrl+space bar 자동생성됨.
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "버튼을 누르셨군요....", Toast.LENGTH_LONG).show();
                // resld 는 무시한다. 그대로 놔둠. 나중에 자동으로 변경됨.
        // 3. 처리할 내용은 DietActivity를 시작
// 자동주석처리 방법 : ctrl + " / "
//                1) 화면에서 처리하고자 하는 View를 찾으세요.
//                    findByView
//                    reStart button!!
//                2) 클릭했을 때, DietActivity 가 열리도록 처리
//                   ㅇ 액티비티를 넘길 때는...
//                    2-1) 액티비티를 넘길 수 있는 부품을 셋팅한다.
//                         intent 라는 부품을 복사해서 가지고 온 다음.
//                         현재 액티비티 ☞ 가야할 액티비티  세팅
                Intent go = new Intent(getApplicationContext(), DietActivity2.class);

//                     2-2)  intent 부품 시작!!!
                startActivity(go);
            }
        });
    }
}
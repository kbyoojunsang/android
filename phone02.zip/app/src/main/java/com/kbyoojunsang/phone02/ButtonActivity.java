package com.kbyoojunsang.phone02;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ButtonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button);

        //  1. 레이아웃에 있는 View 를 선택
        Button toast = findViewById(R.id.toast);
        // 위 소문자 toast는 버튼의 이름이다. 변경가능하다.
        //  2. Button 을 가지고 와서 액션 처리
        toast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "내가 바로 토스트에요", Toast.LENGTH_LONG).show();
                // 위 대문자 Toast는 부품의 이름이다. 변경금지!!
                //  3. toast를 띄운다.
            }
        });

        //1. 레이아웃 중에서 내가 처리하고 싶은
        // view를 찾아서 선택해라
        Button tel = findViewById(R.id.tell);
        // 2. view를 어떻게 처리할지 코딩
        tel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "전화를 겁니다.", Toast.LENGTH_LONG).show();
                // 위 대문자 Toast는 부품의 이름이다. 변경금지!!
                //  3. Toast를 띄운다.
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-0000-0000"));
                startActivity(intent);
            }
        });

        //1. 레이아웃 중에서 내가 처리하고 싶은
        // view를 찾아서 선택해라
        Button find = findViewById(R.id.find);
        // 2. view를 어떻게 처리할지 코딩
        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "브라우저를 엽니다.", Toast.LENGTH_LONG).show();
                // 위 대문자 Toast는 부품의 이름이다. 변경금지!!
                //  3. Toast를 띄운다.
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.naver.com"));
                startActivity(intent);
            }
        });

        //1. 레이아웃 중에서 내가 처리하고 싶은
        // view를 찾아서 선택해라

        Button mylogin = findViewById(R.id.mylogin);
        // 2. view를 어떻게 처리할지 코딩
        mylogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "로그인화면으로 갑니다.", Toast.LENGTH_LONG).show();
                // 위 대문자 Toast는 부품의 이름이다. 변경금지!!
                //  3. Toast를 띄운다.
                Intent intent = new Intent(getApplicationContext(), MyLoginActivity.class);
                startActivity(intent);
            }
        });

    }
}

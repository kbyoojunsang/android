package com.kbyoojunsang.phone02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MyLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_login);

        EditText idText = findViewById(R.id.idText);
        EditText pwText = findViewById(R.id.pwText);

        // 입력을 해라. 입력한거를 string 으로 변환
        String id = idText.getText().toString();
        String pw = pwText.getText().toString();

        // id pass 설정
        String oriId = "root";
        String oriPw = "pass";

        // if 문으로 체크
        if(id.equals(oriId) && pw.equals(oriPw)) {
            Toast.makeText(getApplicationContext(), "로그인 성공. 메모장으로 넘어갑니다.", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(getApplicationContext(), "로그인 실패. 재로그인 해주세요.", Toast.LENGTH_LONG).show();
        }


        // intent로 넘기기



        /*
        // 내가 혼자 해본거
        Button login = findViewById(R.id.login);
        // 2. view를 어떻게 처리할지 코딩
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "메모장 화면으로 갑니다.", Toast.LENGTH_LONG).show();
                // 위 대문자 Toast는 부품의 이름이다. 변경금지!!
                //  3. Toast를 띄운다.
                Intent intent = new Intent(getApplicationContext(), MemoActivity.class);
                startActivity(intent);
            }
        });
*/
    }
}
